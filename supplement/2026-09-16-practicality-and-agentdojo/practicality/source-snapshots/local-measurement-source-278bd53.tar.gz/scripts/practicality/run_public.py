"""Receipt-backed native Hermes and checkpoint experiments. No model calls.

Run on a fresh dedicated store. Private role keystores live outside the checkout.
The same runner can be validated on Anvil; remote mode requires committed source.
"""
from __future__ import annotations

import argparse
import asyncio
import hashlib
import json
import os
from pathlib import Path
import platform
import random
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "scripts"))
import _config as C
import requests
from web3 import Web3
from aa_sdk import HttpStore
from aa_sdk.chain import EscrowClient
from aa_commons import ActionRecord, trace_hash, registry
from aa_verifier import process_challenge
from run_evidence import (Journal, RecordedEscrow, json_value, validate_revision,
    validate_store_inventory, confirmed_runtime, confirmed_operator, module_sources)
import aa_sdk, aa_commons, aa_verifier

PAYOUT = 10**10
BOND = 10**10
ROLE_FUNDS = {"provider": 5 * 10**14, "verifier": 3 * 10**14, "challenger": 10**14}
MAX_GAS_PRICE = 10**8
MAX_GAS = 3_000_000
HERMES_REVISION = "9801de7052b9f746791f96600ea19b9399de4b13"
STRATEGIES = {"10_records_or_30s": (10, 30), "30_records_or_60s": (30, 60),
              "final_only": (10**9, 86400)}


def utc():
    return datetime.now(timezone.utc).isoformat()


def write_json(path, data):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(json_value(data), indent=2) + "\n")
    tmp.replace(path)


class LimitedSigner:
    """Reject unexpectedly costly/wrong-network transactions before SDK signing."""
    def __init__(self, account, target=None):
        self.account, self.address, self.target = account, account.address, target

    def sign_transaction(self, transaction):
        if transaction.get("chainId") != C.CHAIN_ID:
            raise ValueError("refusing transaction on wrong chain")
        if int(transaction["gas"]) > MAX_GAS:
            raise ValueError("gas limit exceeds experiment ceiling")
        price = int(transaction.get("maxFeePerGas", transaction.get("gasPrice", 0)))
        if not 0 < price <= MAX_GAS_PRICE:
            raise ValueError("gas price exceeds experiment ceiling")
        if int(transaction.get("value", 0)) > PAYOUT:
            raise ValueError("transaction value exceeds tiny experimental reserve/bond")
        if self.target and Web3.to_checksum_address(transaction["to"]) != self.target:
            raise ValueError("transaction target differs from experimental escrow")
        return self.account.sign_transaction(transaction)


class EvidenceJournal(Journal):
    def transaction(self, operation, receipt, elapsed):
        with self.lock:
            super().transaction(operation, receipt, elapsed)
            self.manifest["transactions"][-1].update({
                "observed_at_unix": time.time(), "receipt": json.loads(Web3.to_json(receipt))})
            self.write()


class NativeHermes:
    """Actual patched dispatch/approval hooks with controlled ACP user responses."""
    def __init__(self, hermes_root, fixtures):
        self.root, self.fixtures = Path(hermes_root).resolve(), Path(fixtures).resolve()
        actual = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=self.root, text=True).strip()
        dirty = subprocess.check_output(["git", "status", "--porcelain"], cwd=self.root, text=True).strip()
        if actual != HERMES_REVISION or dirty:
            raise ValueError("Hermes must be the clean pinned native fork")
        self.fixtures.mkdir(parents=True, exist_ok=True)
        (self.fixtures / "workspace").mkdir(exist_ok=True)
        os.environ["HERMES_HOME"] = str(self.fixtures / "hermes-home")
        os.environ["HERMES_INTERACTIVE"] = "1"
        os.environ["AA_SCOPE_PREFIX"] = str(self.fixtures / "workspace") + "/"
        for path in (str(self.root), str(ROOT / "integrations/hermes")):
            sys.path.insert(0, path)
        import model_tools
        import aa_hermes
        from hermes_cli.plugins import get_plugin_manager
        self.plugin, self.dispatch = aa_hermes, model_tools.handle_function_call
        manager = get_plugin_manager()
        manager._hooks, manager._middleware = {}, {}
        class Context:
            def register_hook(self, name, callback):
                manager._hooks.setdefault(name, []).append(callback)
            def register_middleware(self, name, callback):
                manager._middleware.setdefault(name, []).append(callback)
        aa_hermes.register(Context())
        self.loop = asyncio.new_event_loop()
        self.thread = threading.Thread(target=self.loop.run_forever, daemon=True)
        self.thread.start()
        self.sources = {"model_tools": str(Path(model_tools.__file__).resolve()),
                        "aa_hermes": str(Path(aa_hermes.__file__).resolve())}

    def begin(self, name, store, escrow, provider, party, cadence=(10, 30)):
        acc, session = self.plugin.begin_session(party=party, store=store, chain=escrow,
            provider_addr=provider, payout_wei=PAYOUT, native_session_id=name)
        acc.checkpoint_records, acc.checkpoint_seconds = cadence
        return acc, session

    def write(self, name, index, *, outside=False, decision="allow_once"):
        from acp.schema import AllowedOutcome
        from acp_adapter.edit_approval import (make_acp_edit_approval_requester,
            set_edit_approval_requester, reset_edit_approval_requester)
        async def answer(**kwargs):
            return SimpleNamespace(outcome=AllowedOutcome(outcome="selected", option_id=decision))
        token = (set_edit_approval_requester(make_acp_edit_approval_requester(answer, self.loop, name))
                 if decision is not None else None)
        path = self.fixtures / ("outside" if outside else "workspace") / f"{name}-{index}.txt"
        path.parent.mkdir(exist_ok=True)
        content = f"native experiment fixture {index}\n" + "x" * 1024
        try:
            started = time.perf_counter()
            result = self.dispatch("write_file", {"path": str(path), "content": content},
                session_id=name, tool_call_id=f"{name}-{index}")
            elapsed = time.perf_counter() - started
            if decision != "deny":
                assert path.read_text() == content, result
            else:
                assert not path.exists(), result
            return {"tool": "write_file", "path": str(path), "result": result,
                    "effect_sha256": hashlib.sha256(content.encode()).hexdigest() if path.exists() else None,
                    "action_seconds": elapsed, "completed_at_unix": time.time()}
        finally:
            if token is not None:
                reset_edit_approval_requester(token)

    def end(self, name):
        return self.plugin.end_session(native_session_id=name)


def snapshot(escrow, store, session):
    state = escrow.get_session(session.session_id)
    return {"records": store.get_records(session.session_id),
            "final_trace_hash": Web3.to_hex(state[2]), "opened_at": state[3],
            "committed_at": state[4], "checkpoints": escrow.get_checkpoints(session.session_id)}


def verifier_main(args):
    """Separate process loads only the verifier signing key and committed metadata."""
    w3 = C.w3()
    actors = C.verifier_actors(w3)
    address = C.load_deployment()["address"]
    accounts = {a: LimitedSigner(k, address) for a, k in actors.values() if k is not None}
    escrow = C.escrow_client(w3, actors)
    recorded = RecordedEscrow(w3, address, escrow.contract.abi, accounts)
    recorded._confirmed_block = args.min_block
    manifest = {"pid": os.getpid(), "actors_loaded": ["verifier"], "transactions": [], "attempts": []}
    recorded.journal = EvidenceJournal(Path(args.output), manifest)
    store = HttpStore(C.STORE_URL)
    if args.fault == "unavailable":
        original = store
        class Unavailable:
            def get_records(self, sid):
                raise ConnectionError("controlled evidence-availability fault")
            def get_promise(self, pid):
                return original.get_promise(pid)
        store = Unavailable()
    elif args.fault == "rewrite":
        original = store
        presented = json.loads(Path(args.presented).read_text())
        class Rewritten:
            def get_records(self, sid):
                return presented
            def get_promise(self, pid):
                return original.get_promise(pid)
        store = Rewritten()
    started = time.perf_counter()
    manifest["verdict"] = process_challenge(recorded, store, args.challenge, actors["verifier"][0])
    manifest["elapsed_seconds"] = time.perf_counter() - started
    recorded.journal.write()


def run(args):
    output = Path(args.output).resolve()
    if output.exists():
        raise ValueError("preserve prior evidence; use a new output path")
    revision = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip()
    dirty = subprocess.check_output(["git", "status", "--porcelain"], cwd=ROOT, text=True).strip()
    validate_revision(revision, dirty, C.CHAIN_ID, args.allow_dirty)
    w3, store = C.w3(), HttpStore(C.STORE_URL)
    actors = C.actors(w3)
    provider, challenger, verifier = (actors[r][0] for r in ("provider", "challenger", "verifier"))
    if len({provider, challenger, verifier}) != 3:
        raise ValueError("distinct role addresses required")
    response = requests.get(f"{C.STORE_URL}/inventory", timeout=10)
    response.raise_for_status()
    validate_store_inventory(response.json())
    artifact = Path(C.ARTIFACT).read_bytes()
    compiled = json.loads(artifact)
    metadata = compiled["metadata"]
    metadata = json.loads(metadata) if isinstance(metadata, str) else metadata
    source = (ROOT / "contracts/src/Escrow.sol").read_bytes()
    assert metadata["sources"]["src/Escrow.sol"]["keccak256"] == Web3.to_hex(Web3.keccak(source))
    native = NativeHermes(args.hermes_root, args.fixtures)
    output.parent.mkdir(parents=True, exist_ok=True)
    manifest = {"status": "running", "started_at_utc": utc(), "source_revision": revision,
        "source_dirty": bool(dirty), "chain_id": C.CHAIN_ID,
        "artifact_sha256": hashlib.sha256(artifact).hexdigest(), "hermes_revision": HERMES_REVISION,
        "module_sources": module_sources((aa_sdk, aa_commons, aa_verifier, C)),
        "native_modules": native.sources, "machine": platform.platform(),
        "actors": {r: actors[r][0] for r in actors}, "transactions": [], "attempts": [],
        "scenarios": [], "checkpoint_runs": [], "predicates": registry.catalog(),
        "payout_wei": PAYOUT, "challenge_bond_wei": BOND,
        "clock_policy": "unchanged contract deadlines, no mainnet time travel",
        "capture_origin": "real Hermes tool handler/ACP approval hooks; deterministic controlled user answers, no model",
        "roles": "separate keys; verifier in separate process; one experimental operator",
        "checkpoint_workload": {"actions": args.actions, "interval_seconds": args.interval,
            "pause_after_actions": 2, "pause_seconds": args.pause, "repetitions": args.repetitions},
        "balances_before_wei": {r: w3.eth.get_balance(actors[r][0]) for r in ROLE_FUNDS}}
    journal = EvidenceJournal(output, manifest)
    accounts = {a: LimitedSigner(k) for a, k in actors.values() if k is not None}
    try:
        ctor = w3.eth.contract(abi=compiled["abi"], bytecode=compiled["bytecode"]["object"]).constructor(verifier)
        gas = ctor.estimate_gas({"from": verifier})
        assert gas <= MAX_GAS
        manifest["deployment_estimate_gas"] = gas
        journal.write()
        started = time.perf_counter()
        attempt = journal.attempt("deploy", sender=verifier, function_args=(verifier,))
        deployed = EscrowClient.deploy(w3, C.ARTIFACT, verifier, verifier, accounts)
        journal.update_attempt(attempt, state="confirmed", transaction_hash=Web3.to_hex(deployed.deploy_receipt.transactionHash))
        journal.transaction("deploy", deployed.deploy_receipt, time.perf_counter() - started)
        address = deployed.contract.address
        for account in accounts.values():
            account.target = address
        escrow = RecordedEscrow(w3, address, deployed.contract.abi, accounts)
        escrow.journal, escrow.deploy_block = journal, deployed.deploy_block
        escrow._observe_receipt(deployed.deploy_receipt)
        manifest["contract_address"] = address
        confirmed_runtime(w3, address, bytes.fromhex(compiled["deployedBytecode"]["object"].removeprefix("0x")), deployed.deploy_block)
        confirmed_operator(escrow.contract, verifier, deployed.deploy_block)
        C.save_deployment({"address": address, "deploy_block": deployed.deploy_block, "provider_addr": provider,
            "challenger_addr": challenger, "verifier_addr": verifier, "source_revision": revision,
            "artifact_sha256": manifest["artifact_sha256"], "promises": {}})
        journal.write()

        def settle(name, acc, session, expected, fault="none", presented=None, promise_index=0):
            pid = acc.promises[promise_index].promise_id
            before = escrow.get_promise(pid)[4]
            credit_before = escrow.bond_of(provider)
            cid = escrow.challenge(challenger, session.session_id, pid, BOND)
            if fault != "none":
                escrow.respond(provider, cid)
            # The challenger sends no transaction during verification, so its balance delta
            # must equal the transfer in the settlement event without a gas correction.
            balance_before = escrow._read(lambda block: w3.eth.get_balance(challenger, block))
            verdict_path = output.parent / f"{name}-verifier.json"
            command = [sys.executable, __file__, "verify", "--output", str(verdict_path),
                       "--challenge", str(cid), "--fault", fault,
                       "--min-block", str(escrow._confirmed_block)]
            if presented:
                command += ["--presented", str(presented)]
            subprocess.run(command, check=True)
            result = json.loads(verdict_path.read_text())
            journal.manifest["transactions"].extend(result["transactions"])
            journal.manifest["attempts"].extend(result["attempts"])
            last_block = max(t["block_number"] for t in result["transactions"])
            escrow._confirmed_block = max(escrow._confirmed_block, last_block)
            balance_after = escrow._read(lambda block: w3.eth.get_balance(challenger, block))
            after, credit_after = escrow.get_promise(pid)[4], escrow.bond_of(provider)
            verdict = result["verdict"]
            assert verdict["violated"] is expected, verdict
            assert before - after == (PAYOUT if expected else 0)
            assert credit_after - credit_before == (0 if expected else BOND)
            assert balance_after - balance_before == (PAYOUT + BOND if expected else 0)
            assert verdict["paid_to_challenger"] == balance_after - balance_before
            row = {"name": name, "session_id": session.session_id, "challenge_id": cid,
                "promise_id": pid, "verdict": verdict, "verifier_process": result["pid"],
                "reserve_before_wei": before, "reserve_after_wei": after,
                "challenger_balance_delta_wei": balance_after - balance_before,
                "provider_credit_delta_wei": credit_after - credit_before,
                "promise": store.get_promise(pid), **snapshot(escrow, store, session)}
            manifest["scenarios"].append(row)
            journal.write()
            return row

        for rep in range(args.repetitions):
            for outside in (False, True):
                name = f"native-{'outside' if outside else 'within'}-{rep}"
                acc, session = native.begin(name, store, escrow, provider, challenger)
                effect = native.write(name, 0, outside=outside)
                auths = [r for r in session.records if r.tool == "user_authorization"]
                assert len(auths) == 1 and auths[0].args["decision"] == "allow"
                assert session.checkpoint(force=True)["success"]
                native.end(name)
                row = settle(name, acc, session, outside)
                row["tool_effect"] = effect
                row["authorization_verdict"] = json_value(acc.self_check(session.records)[acc.promises[1].promise_id].__dict__)
                assert row["authorization_verdict"]["violated"] is False
                if not outside:
                    settle(name + "-authorization", acc, session, False, promise_index=1)
                journal.write()

            name = f"native-without-approval-{rep}"
            acc, session = native.begin(name, store, escrow, provider, challenger)
            effect = native.write(name, 0, decision=None)
            assert not any(r.tool == "user_authorization" for r in session.records)
            assert session.checkpoint(force=True)["success"]
            native.end(name)
            row = settle(name, acc, session, True, promise_index=1)
            row["tool_effect"] = effect
            journal.write()

        for fault in ("unavailable", "rewrite"):
            name = "controlled-" + fault
            acc, session = native.begin(name, store, escrow, provider, challenger,
                                        cadence=STRATEGIES["final_only"])
            effect = native.write(name, 0)
            assert session.checkpoint(force=True)["success"]
            presented_path = None
            if fault == "rewrite":
                rewritten = store.get_records(session.session_id)
                rewritten[-1]["args"]["content"] = "controlled changed prefix"
                presented_path = output.parent / "presented-rewrite.json"
                write_json(presented_path, rewritten)
                # Controlled malicious provider bypasses normal SDK finalization; the actual
                # append-only store stays intact. The verifier receives the changed copy.
                session._stop.set()
                session._wake.set()
                if session._worker:
                    session._worker.join(timeout=5)
                escrow.commit_trace(provider, session.session_id,
                    trace_hash([ActionRecord.from_dict(r) for r in rewritten]))
            else:
                native.end(name)
            row = settle(name, acc, session, True, fault, presented_path)
            row["tool_effect"] = effect
            journal.write()

        schedule = [(rep, name) for rep in range(args.repetitions) for name in STRATEGIES]
        random.Random(20260916).shuffle(schedule)
        for rep, strategy in schedule:
            name = f"checkpoint-{strategy}-{rep}"
            acc, session = native.begin(name, store, escrow, provider, challenger, STRATEGIES[strategy])
            effects, samples = [], []
            stop = threading.Event()
            def sample():
                while not stop.wait(0.05):
                    samples.append({"at_unix": time.time(), **session.checkpoint_status()})
            monitor = threading.Thread(target=sample, daemon=True)
            monitor.start()
            started = time.perf_counter()
            start_tx = len(manifest["transactions"])
            for i in range(args.actions):
                if i == 2:
                    time.sleep(args.pause)
                effects.append(native.write(name, i))
                time.sleep(args.interval)
            action_span = time.perf_counter() - started
            finalize_start = time.perf_counter()
            native.end(name)
            finalized = time.perf_counter() - finalize_start
            stop.set()
            monitor.join(timeout=2)
            txs = manifest["transactions"][start_tx:]
            row = {"name": name, "strategy": strategy, "repetition": rep,
                "session_id": session.session_id, "tool_effects": effects,
                "action_span_seconds": action_span, "finalization_seconds": finalized,
                "checkpoint_samples": samples, "transactions": txs,
                "cadence_records": acc.checkpoint_records, "cadence_seconds": acc.checkpoint_seconds,
                **snapshot(escrow, store, session)}
            assert len(row["records"]) == args.actions * 4, len(row["records"])
            assert all(not v.violated for v in acc.self_check(session.records).values())
            if strategy == "final_only":
                assert not row["checkpoints"]
            assert all(t["status"] == 1 for t in txs)
            manifest["checkpoint_runs"].append(row)
            journal.write()
            print("checkpoint experiment completed", strategy, rep, len(row["checkpoints"]), flush=True)

        manifest["balances_after_wei"] = {r: escrow._read(lambda block, r=r: w3.eth.get_balance(actors[r][0], block)) for r in ROLE_FUNDS}
        manifest["contract_balance_wei"] = escrow._read(lambda block: w3.eth.get_balance(address, block))
        fees = [t["execution_plus_l1_fee_wei"] for t in manifest["transactions"]]
        manifest["total_fee_wei"] = sum(fees) if all(v is not None for v in fees) else None
        manifest["status"] = "passed" if all(a["state"] == "confirmed" for a in manifest["attempts"]) else "incomplete_attempt_journal"
        manifest["finished_at_utc"] = utc()
        journal.write()
    except Exception as error:
        manifest.update(status="failed", error=f"{type(error).__name__}: {error}", finished_at_utc=utc())
        journal.write()
        raise


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    verify = sub.add_parser("verify")
    verify.add_argument("--output", required=True)
    verify.add_argument("--challenge", type=int, required=True)
    verify.add_argument("--fault", choices=["none", "unavailable", "rewrite"], default="none")
    verify.add_argument("--presented")
    verify.add_argument("--min-block", type=int, default=0)
    run_parser = sub.add_parser("run")
    run_parser.add_argument("--output", required=True)
    run_parser.add_argument("--hermes-root", required=True)
    run_parser.add_argument("--fixtures", required=True)
    run_parser.add_argument("--allow-dirty", action="store_true")
    run_parser.add_argument("--repetitions", type=int, default=3)
    run_parser.add_argument("--actions", type=int, default=20)
    run_parser.add_argument("--interval", type=float, default=0.25)
    run_parser.add_argument("--pause", type=float, default=35)
    args = parser.parse_args()
    verifier_main(args) if args.command == "verify" else run(args)

if __name__ == "__main__":
    main()
