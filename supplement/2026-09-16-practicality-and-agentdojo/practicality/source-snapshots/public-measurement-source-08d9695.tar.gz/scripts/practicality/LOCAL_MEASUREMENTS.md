# Local practicality measurements

Use the pinned Hermes fork `9801de7052b9f746791f96600ea19b9399de4b13` and its Python environment. Build the current contract first (`forge build` from `contracts/`; `forge build --skip test` is sufficient when the optional forge-std test dependency is absent).

```sh
/Users/chenghua/research/hermes-agent/.venv/bin/python scripts/practicality/measure_local.py \
  --output /Users/chenghua/research/.local/base-mainnet-eval-20260916/results/local-performance
```

The script refuses an existing store database. Use a new output directory for another run. Its services bind only localhost ports 18547 and 18548; Anvil must report chain 31337. It uses newly started Anvil unlocked accounts, never reads wallet files, and cannot select a public RPC URL. Services are stopped when the run ends or fails. Imports bind to this checkout through `scripts/_config.py`.

## Native runtime

One warmup per mode precedes 30 paired repetitions. Seed 20260916 randomizes mode order within each repetition. The three modes are capture disabled, native adapter plus HttpStore, and native adapter plus HttpStore plus actual local Anvil checkpoints. All modes drive the pinned `model_tools.handle_function_call` and real `write_file` handler through ACP approval. Only the ACP transport response is controlled (`allow_once`, immediate); no model generation or human response delay is timed. Capture disabled removes only accountability hook/middleware registration, keeping the native ACP approval path.

Each repetition writes the same 100 paths and identical 1 KiB contents after removing the previous files outside the measured interval. It verifies every file hash, both registered predicate verdicts, all 400 stored records (request, response, normalized authorization, action), and the final trace hash. It preserves the raw workload and one captured trace. The workload models approved small-file writes, not a general distribution of agent tools.

Report session setup, action loop, each dispatch latency, and finalization separately. The action loop includes result JSON parsing and error checks; individual dispatch latency ends before those checks. Finalization includes waiting for an in-flight checkpoint, store reread, historical prefix checks, and final commitment. Chain call spans include SDK submission and observed-receipt wait; checkpoints can overlap action execution, so do not add their spans to action time. Local instant mining is not a mainnet latency estimate.

CPU covers the client process and separately the store/Anvil child processes during actions plus finalization. Store bytes count the UTF-8 SQLite record payloads for that session. Database size is cumulative allocated file size, not a per-session storage estimate. Output effect bytes exclude filesystem metadata. Paired bootstrap confidence intervals resample the 30 repetition-level differences; they do not treat all 3000 action latencies as independent runs.

## Verifier scaling

The 100/1000/10000-record inputs repeat a real captured four-record authorization/action block, with new action/request IDs, contiguous sequences, a new session, and consistent grants. These are expanded native-shaped fixtures, not claims that 10000 new native actions were executed. The script checks their authorization predicate before timing. Data is loaded through the real append HTTP API outside timed verification.

Five fresh subprocesses at each size run the actual `aa_verifier.process_challenge`, HttpStore retrieval, canonical final hash, `check_prefixes`, hash-based predicate resolution, and invocation-authorization evaluation. A fixture escrow supplies expected roots and stubs settlement; chain RPC retrieval and settlement latency are excluded. Phase wrappers measure real production functions without changing their inputs or semantics. Record deserialization, parameter validation, and predicate lookup are included in total time but not separately attributed.

Each size is measured with cumulative checkpoints every 10 records and with final commitment only. The every-10 profile deliberately stresses a dense checkpoint history; asynchronous SDK checkpoints in native runs may cover more than 10 records. Current `check_prefixes` rehashes each cumulative prefix, giving quadratic total hashed data at a fixed record cadence. Report the number of checkpoints with timing. Memory uses OS process peak RSS in a fresh worker, plus the baseline high-water mark and their difference; it is not Python-only allocation and the growth is not a precise live-heap delta.

## Cadence

Three repetitions of each policy run concurrently on local Anvil: 10 records/30 seconds, 30 records/60 seconds, and final only (thresholds larger than the workload). These are explicitly synthetic SDK records, with no native execution latency claim. Each session emits 20 records at 0.2-second intervals, idles, then emits 20 more beginning at 69 seconds. The idle interval exercises actual timer checkpoints. Session concurrency and shared sender nonce serialization affect latency.

Raw artifacts retain record emission and observed receipt timestamps, transaction counts and local gas use, per-record anchor delays, and maximum unanchored count/age. A record timestamp is sampled immediately before `Session.record`; it includes its short allocation overhead. Anchoring means receipt observed on local Anvil, not L1 finality. Local gas prices/fees must not be reported as Base mainnet fees.
