"""Safety bounds and evidence serialization for the experiment sender."""
import importlib.util
from pathlib import Path
from types import SimpleNamespace

import pytest
from web3 import Web3
from web3.datastructures import AttributeDict

spec = importlib.util.spec_from_file_location("run_public", Path(__file__).with_name("run_public.py"))
run = importlib.util.module_from_spec(spec)
spec.loader.exec_module(run)


def test_signer_rejects_wrong_network_unbounded_value_or_gas():
    calls = []
    account = SimpleNamespace(address="0x" + "11" * 20, sign_transaction=lambda tx: calls.append(tx))
    target = Web3.to_checksum_address("0x" + "22" * 20)
    signer = run.LimitedSigner(account, target)
    base = dict(chainId=run.C.CHAIN_ID, gas=21000, gasPrice=6_000_000, value=run.PAYOUT, to=target)
    for changes in ({"chainId": 1}, {"value": run.PAYOUT + 1}, {"gas": run.MAX_GAS + 1},
                    {"gasPrice": run.MAX_GAS_PRICE + 1}, {"to": account.address}):
        with pytest.raises(ValueError):
            signer.sign_transaction({**base, **changes})
    assert not calls
    signer.sign_transaction(base)
    assert calls == [base]


def test_receipt_with_nested_logs_remains_serializable(tmp_path):
    manifest = {"transactions": [], "attempts": []}
    journal = run.EvidenceJournal(tmp_path / "evidence.json", manifest)
    receipt = AttributeDict({"transactionHash": bytes.fromhex("ab" * 32), "blockNumber": 7,
        "status": 1, "gasUsed": 20000, "effectiveGasPrice": 6000000,
        "logs": [AttributeDict({"address": "0x" + "22" * 20, "data": b"\x01"})]})
    journal.transaction("example", receipt, 0.5)
    assert manifest["transactions"][0]["receipt"]["logs"][0]["data"] == "0x01"
