"""Prepare fresh experiment roles and transfer a bounded allowance from a dedicated wallet.

No key material is printed. No automatic retries: uncertain submissions retain their
precomputed transaction hash for read-only reconciliation.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import os
from pathlib import Path
import secrets
import sys
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import _config as C
from eth_account import Account
from web3 import Web3
from run_public import ROLE_FUNDS, MAX_GAS_PRICE, MAX_GAS, write_json


def prepare(directory):
    directory = Path(directory)
    roles = directory / "roles"
    roles.mkdir(mode=0o700, exist_ok=True)
    addresses = {}
    for role in ROLE_FUNDS:
        key_path, password_path = roles / f"{role}.json", roles / f"{role}.password"
        if key_path.exists() or password_path.exists():
            raise ValueError("role files already exist; do not overwrite experimental keys")
        account, password = Account.create(), secrets.token_hex(32)
        for path, value in ((key_path, json.dumps(Account.encrypt(account.key, password))),
                            (password_path, password)):
            with os.fdopen(os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600), "w") as f:
                f.write(value + "\n")
        recovered = Account.from_key(Account.decrypt(json.loads(key_path.read_text()), password_path.read_text().strip()))
        assert recovered.address == account.address
        addresses[role] = account.address
    write_json(directory / "roles-public.json", addresses)
    print(json.dumps(addresses, indent=2))


def preflight(directory):
    if C.CHAIN_ID != 8453 or C.LOCAL:
        raise ValueError("this bounded funding plan is only for explicitly configured Base mainnet")
    directory = Path(directory)
    w3 = C.w3()
    funding = json.loads((directory / "wallet.json").read_text())["address"]
    addresses = json.loads((directory / "roles-public.json").read_text())
    assert len(set(addresses.values()) | {funding}) == 4
    for role, address in addresses.items():
        assert C.role_wallet(role)[0] == address
        assert w3.eth.get_transaction_count(address, "pending") == 0
        assert w3.eth.get_balance(address) == 0, "fresh role addresses required"
    assert not w3.eth.get_code(funding), "funding account must be an EOA"
    artifact = json.loads(Path(C.ARTIFACT).read_text())
    ctor = w3.eth.contract(abi=artifact["abi"], bytecode=artifact["bytecode"]["object"]).constructor(addresses["verifier"])
    gas = ctor.estimate_gas({"from": funding})
    assert gas <= MAX_GAS
    price = w3.eth.gas_price
    assert price <= MAX_GAS_PRICE
    oracle = w3.eth.contract(address="0x420000000000000000000000000000000000000F", abi=[{
        "name": "getL1FeeUpperBound", "type": "function", "stateMutability": "view",
        "inputs": [{"name": "txSize", "type": "uint256"}],
        "outputs": [{"name": "", "type": "uint256"}]}])
    deploy_l1 = oracle.functions.getL1FeeUpperBound(len(ctor.data_in_transaction.removeprefix("0x")) // 2 + 300).call()
    small_l1 = oracle.functions.getL1FeeUpperBound(800).call()
    balance = w3.eth.get_balance(funding)
    # Deliberately conservative planning envelope, not measured performance.
    estimated_plan = (gas + 200 * 210000) * price + deploy_l1 + 200 * small_l1
    assert estimated_plan < sum(ROLE_FUNDS.values()), "estimated plan exceeds role allowance"
    assert balance > sum(ROLE_FUNDS.values()) + 3 * (21000 * MAX_GAS_PRICE + small_l1)
    result = {"at_utc": datetime.now(timezone.utc).isoformat(), "chain_id": 8453,
        "funding_address": funding, "funding_balance_wei": balance, "role_addresses": addresses,
        "role_allowances_wei": ROLE_FUNDS, "total_role_allowance_wei": sum(ROLE_FUNDS.values()),
        "deployment_estimate_gas": gas, "gas_price_wei": price,
        "deployment_l1_fee_upper_estimate_wei": deploy_l1,
        "small_transaction_l1_fee_upper_estimate_wei": small_l1,
        "planning_envelope_wei": estimated_plan,
        "planning_assumption": "one deployment plus 200 transactions at 210000 gas each; current fees, not guarantee",
        "artifact_sha256": hashlib.sha256(Path(C.ARTIFACT).read_bytes()).hexdigest()}
    return w3, result


def fund(directory, output):
    output, directory = Path(output), Path(directory)
    if output.exists():
        raise ValueError("funding journal already exists; reconcile it, never repeat automatically")
    w3, report = preflight(directory)
    report["transfers"] = []
    write_json(output, report)
    key_path, password_path = directory / "keystore.json", directory / "keystore-password.txt"
    assert not (key_path.stat().st_mode & 0o077 or password_path.stat().st_mode & 0o077)
    account = Account.from_key(Account.decrypt(json.loads(key_path.read_text()), password_path.read_text().strip()))
    assert account.address == report["funding_address"]
    for role, value in ROLE_FUNDS.items():
        block = w3.eth.get_block("latest")
        maximum = 2 * int(block["baseFeePerGas"]) + 1000000
        assert maximum <= MAX_GAS_PRICE
        tx = {"chainId": 8453, "nonce": w3.eth.get_transaction_count(account.address, "pending"),
              "to": report["role_addresses"][role], "value": value, "gas": 21000,
              "maxFeePerGas": maximum, "maxPriorityFeePerGas": 1000000}
        signed = account.sign_transaction(tx)
        txhash = Web3.to_hex(Web3.keccak(signed.raw_transaction))
        row = {"role": role, "transaction": tx, "hash": txhash, "state": "prepared"}
        report["transfers"].append(row)
        write_json(output, report)
        try:
            actual = w3.eth.send_raw_transaction(signed.raw_transaction)
            assert Web3.to_hex(actual) == txhash
            row["state"] = "submitted"
            write_json(output, report)
            receipt = w3.eth.wait_for_transaction_receipt(actual)
            assert receipt.status == 1
            row.update(state="confirmed", receipt=json.loads(Web3.to_json(receipt)))
            write_json(output, report)
            print(role, txhash, "confirmed", flush=True)
        except Exception as e:
            row["error"] = f"{type(e).__name__}: {e}"
            write_json(output, report)
            raise


if __name__ == "__main__":
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=["prepare", "preflight", "fund"])
    p.add_argument("--directory", required=True)
    p.add_argument("--output")
    a = p.parse_args()
    if a.mode == "prepare":
        prepare(a.directory)
    elif a.mode == "preflight":
        _, report = preflight(a.directory)
        write_json(a.output, report)
        print(json.dumps(report, indent=2))
    else:
        fund(a.directory, a.output)
