# Native capture and public settlement experiment

Run `run_public.py` with the pinned Hermes runtime after building `contracts/`.
The runner uses actual Hermes dispatch, native ACP approval requests/responses, the
adapter, SDK, HTTP store, unchanged Escrow contract and a separate verifier process.
User responses are controlled and tool inputs deterministic; no model is invoked.
One operator controls all three roles. The verifier child loads only its role key;
this is process separation, not an independently administered service.

Use a fresh dedicated SQLite/HTTP store for each deployment. `AA_LOCAL=1` selects
Anvil; public execution requires `AA_LOCAL=0`, `AA_CHAIN_ID=8453`,
`AA_KEYSTORE_DIR` pointing outside the repository, and committed source. A clean
Hermes checkout at `9801de7052b9f746791f96600ea19b9399de4b13` is required.
`AA_DEPLOYMENT` and all output/fixture paths should point to an isolated experiment
directory outside the source checkout. Keep keystores and passwords private.

`prepare_funding.py prepare` creates encrypted role keys in the supplied private
directory. `preflight` checks the chain, fresh role accounts, build, actual deploy
gas, and an L1 fee upper estimate. `fund` transfers fixed role allowances totaling
0.0009 ETH from the separately supplied dedicated funding wallet. Its journal
records each transaction hash before submission; it never retries automatically.
The runner additionally limits each signature to its configured chain/escrow,
3M gas, 0.1 gwei maximum gas price and 1e10 wei reserve or challenge bond. Only the
funded allowance can be spent; no automatic replenishment exists.

The runner tests approved in-scope writes (both scope and authorization challenges),
approved writes outside a declared scope, and writes that the native environment
permits without an explicit human grant although the registered promise requires
one. Each is repeated three times. Controlled store unavailability after a
provider response and a final trace contradicting an anchored prefix are tested
once each. Faults are injected at the verifier's store boundary; the real append-only
store is retained unchanged. Balances, reserves, bond credits, verdict events,
records and raw receipts are preserved. No contract deadline is shortened.

Checkpoint strategies use 10 records/30 seconds, 30 records/60 seconds and final
commitment only. The last is implemented with thresholds exceeding the bounded
workload. Each run executes 20 writes with four native observation records per
write, with 0.25-second spacing and a 35-second pause after the first two writes.
Eight initial records stay below the 10-record threshold, exposing timer behavior.
Run order is shuffled with seed20260916 and each strategy repeated three times.
The action workload is fixed; absolute timing includes native dispatch and RPC
variation. Checkpoint/finalization cost excludes registration/session opening;
the complete experiment total includes both. Receipt observation is not L1 finality.

For a fast local smoke test use `--repetitions 1 --actions 8 --interval 0.05
--pause 0.1 --allow-dirty`; this deliberately does not measure the 30-second timer.
Use default parameters for the reported public cadence comparison. The local
contract tests cover the three-, ten-, and thirty-day deadlines with clock
advancement, which must not be presented as elapsed-time public-network tests.

Public endpoint recovery: `AA_RPC_MIN_INTERVAL` optionally spaces RPC requests;
429 retries reuse exactly the same request, including identical signed bytes for
submission. Record this pacing with any reported latency. `--reuse-deployment`
starts a fresh measurement on a bytecode/role/chain-verified prior deployment and
its original dedicated store after an aborted pilot. It does not replay or erase
prior submissions. Reconcile every uncertain transaction before using it; retain
all pilot journals and fees. The experiment signer now writes each signed
transaction hash before broadcasting, so receipt failures can be reconciled.
