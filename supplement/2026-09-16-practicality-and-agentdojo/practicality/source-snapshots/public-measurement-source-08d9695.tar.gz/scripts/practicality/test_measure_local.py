"""Check that expanded scaling fixtures retain invocation-specific authorization."""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))
from measure_local import expanded_native_records, paired_bootstrap
from aa_commons import ActionRecord, hash_obj, registry


def test_expansion_preserves_authorization_binding_and_detects_removed_grant():
    args = {"path": "workspace/fixture.txt", "content": "fixture"}
    context = {"request_id": "request-original", "native_request_id": "native-request-original",
               "native_session_id": "native-session-original", "tool_name": "write_file", "arguments": args}
    seed = [
        ActionRecord(1, "session-original", "native_authorization_request", context, "requested", 1, {"action_id": "action-original"}),
        ActionRecord(2, "session-original", "native_authorization_response", context, "once", 2, {"action_id": "action-original"}),
        ActionRecord(3, "session-original", "user_authorization", {
            "schema_version": 1, "action_id": "action-original", "request_id": "native-request-original",
            "session_id": "session-original", "tool": "write_file", "args_hash": hash_obj(args),
            "decision": "allow", "scope": "once", "authority": "human"}, "allow", 3, {"action_id": "action-original"}),
        ActionRecord(4, "session-original", "write_file", args, {"success": True}, 4, {"action_id": "action-original"}),
    ]
    records = expanded_native_records([r.to_dict() for r in seed], 100, "new-session")
    assert [r.seq for r in records] == list(range(1, 101))
    assert {r.session_id for r in records} == {"new-session"}
    actions = [r for r in records if r.tool == "write_file"]
    assert len({r.metadata["action_id"] for r in actions}) == 25
    spec = registry.resolve_hash(registry.predicate_hash_for("no_destructive_without_consent"))
    params = {"destructive_tools": ["write_file"], "authorization_mode": "invocation"}
    assert not spec.evaluate(records, params).violated
    missing_grant = spec.evaluate([r for r in records if r.seq != 7], params)
    assert missing_grant.violated and missing_grant.seq == 8


def test_bootstrap_constant_paired_difference_has_exact_interval():
    assert paired_bootstrap([2.] * 30, samples=100) == {"mean": 2., "ci95": [2., 2.]}
