"""Reproducible local native-runtime and verifier measurements; never uses private keys.

Run with the pinned Hermes .venv Python. All RPC transactions target a newly started
loopback Anvil (chain 31337). Measurement artifacts are separate from paper sources.
"""
from __future__ import annotations

import argparse
import asyncio
import copy
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import random
import resource
import socket
import sqlite3
import statistics
import subprocess
import sys
import threading
import time
from types import SimpleNamespace

REPO = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(REPO / "scripts"))
# Set before importing _config; none of its wallet-reading helpers are called.
os.environ["AA_LOCAL"] = "1"
import _config as C
C.bootstrap_packages()
from aa_commons import ActionRecord, params_hash, registry, trace_hash
from aa_commons.trace import check_prefixes
from aa_sdk import Accountability, HttpStore
from aa_sdk.chain import EscrowClient
from web3 import Web3
import requests


def dump(path, value):
    Path(path).write_text(json.dumps(value, indent=2, default=str) + "\n")


def elapsed(fn):
    start = time.perf_counter()
    value = fn()
    return value, time.perf_counter() - start


def rss_bytes():
    value = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(value if sys.platform == "darwin" else value * 1024)


def percentile(values, q):
    values = sorted(values)
    at = (len(values) - 1) * q
    lo = int(at)
    return values[lo] + (values[min(lo + 1, len(values) - 1)] - values[lo]) * (at - lo)


def stats(values):
    return {"n": len(values), "mean": statistics.mean(values),
            "median": statistics.median(values), "p95": percentile(values, .95),
            "min": min(values), "max": max(values)}


def paired_bootstrap(values, seed=20260916, samples=10000):
    rng = random.Random(seed)
    means = [statistics.mean(rng.choices(values, k=len(values))) for _ in range(samples)]
    return {"mean": statistics.mean(values), "ci95": [percentile(means, .025), percentile(means, .975)]}


class Services:
    def __init__(self, args):
        self.args = args
        self.children = []
        self.logs = []

    def __enter__(self):
        args = self.args
        for port in (args.store_port, args.anvil_port):
            with socket.socket() as probe:
                probe.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
                probe.bind(("127.0.0.1", port))
        db = args.output / "trace-store.sqlite"
        if db.exists():
            raise RuntimeError("Use a fresh output directory; refusing to mix runs")
        commands = [
            ([sys.executable, "-m", "uvicorn", "app:app", "--host", "127.0.0.1", "--port", str(args.store_port), "--no-access-log"], REPO / "packages/store", {"STORE_DB": str(db)}),
            ([str(Path.home() / ".foundry/bin/anvil"), "--host", "127.0.0.1", "--port", str(args.anvil_port), "--chain-id", "31337", "--silent"], REPO, {}),
        ]
        dump(args.output / "service-commands.json", [x[0] for x in commands])
        try:
            for name, (cmd, cwd, env) in zip(("store", "anvil"), commands):
                log = open(args.output / f"{name}.log", "w")
                self.logs.append(log)
                self.children.append(subprocess.Popen(cmd, cwd=cwd, env={**os.environ, **env}, stdout=log, stderr=subprocess.STDOUT))
            for _ in range(100):
                try:
                    if requests.get(args.store_url + "/health", timeout=.5).ok and Web3(Web3.HTTPProvider(args.rpc_url)).eth.chain_id == 31337:
                        return self
                except Exception:
                    pass
                if any(p.poll() is not None for p in self.children):
                    raise RuntimeError("Local service exited; inspect logs")
                time.sleep(.1)
            raise RuntimeError("Local services failed readiness")
        except BaseException:
            self.__exit__(None, None, None)
            raise

    def __exit__(self, *unused):
        for child in self.children:
            child.terminate()
        for child in self.children:
            try:
                child.wait(timeout=5)
            except subprocess.TimeoutExpired:
                child.kill()
                child.wait()
        for log in self.logs:
            log.close()


class TimedChain:
    """Instrument the real EscrowClient without replacing submission or reads."""
    def __init__(self, chain):
        self.chain = chain
        self.events = []

    def __getattr__(self, name):
        original = getattr(self.chain, name)
        if name not in {"checkpoint_trace", "commit_trace", "open_session", "register_promise"}:
            return original
        def call(*args, **kwargs):
            start = time.perf_counter()
            result = original(*args, **kwargs)
            end = time.perf_counter()
            event = {"method": name, "start": start, "observed": end, "seconds": end-start,
                     "session_id": args[1] if name != "register_promise" else None}
            if name == "checkpoint_trace":
                event["record_count"] = args[2]
            if name != "register_promise":
                event.update(tx_hash=result.transactionHash.hex(), gas_used=int(result.gasUsed),
                             block=int(result.blockNumber), effective_gas_price=int(result.effectiveGasPrice))
            self.events.append(event)
            return result
        return call


def native_setup(args):
    os.environ["HERMES_HOME"] = str(args.output / "hermes-home")
    os.environ["HERMES_INTERACTIVE"] = "1"
    os.environ["AA_SCOPE_PREFIX"] = str(args.output / "native-files") + "/"
    sys.path.insert(0, str(args.hermes))
    sys.path.insert(0, str(REPO / "integrations/hermes"))
    import aa_hermes
    import model_tools
    from hermes_cli.plugins import get_plugin_manager
    from acp_adapter.edit_approval import make_acp_edit_approval_requester, set_edit_approval_requester, reset_edit_approval_requester
    from acp.schema import AllowedOutcome
    manager = get_plugin_manager()
    manager._hooks, manager._middleware = {}, {}
    class Context:
        def register_hook(self, name, callback):
            manager._hooks.setdefault(name, []).append(callback)
        def register_middleware(self, name, callback):
            manager._middleware.setdefault(name, []).append(callback)
    loop = asyncio.new_event_loop()
    thread = threading.Thread(target=loop.run_forever, daemon=True)
    thread.start()
    async def answer(**kwargs):
        return SimpleNamespace(outcome=AllowedOutcome(outcome="selected", option_id="allow_once"))
    return SimpleNamespace(plugin=aa_hermes, dispatch=model_tools.handle_function_call,
        manager=manager, context=Context(), loop=loop, thread=thread,
        requester=lambda sid: make_acp_edit_approval_requester(answer, loop, sid),
        set_requester=set_edit_approval_requester, reset_requester=reset_edit_approval_requester)


def runtime(args, chain, services):
    import psutil
    native = native_setup(args)
    directory = args.output / "native-files"
    directory.mkdir()
    content = ("native Hermes practicality fixture\n" * 40)[:1024]
    workload = [{"path": str(directory / f"record-{i:04d}.txt"), "content": content} for i in range(args.actions)]
    dump(args.output / "native-workload.json", workload)
    rng = random.Random(args.seed)
    modes = ["capture_off", "http_store", "http_store_anvil"]
    rows = []
    procs = [psutil.Process(p.pid) for p in services.children]
    def service_cpu():
        return [p.cpu_times().user + p.cpu_times().system for p in procs]
    def one(mode, rep, position, warmup=False):
        for entry in workload:
            Path(entry["path"]).unlink(missing_ok=True)
        native.manager._hooks, native.manager._middleware = {}, {}
        sid = f"native-{'warmup' if warmup else rep}-{mode}"
        token = native.set_requester(native.requester(sid))
        acc = sess = None
        mark = len(chain.events)
        setup_start = time.perf_counter()
        if mode != "capture_off":
            native.plugin.register(native.context)
            acc, sess = native.plugin.begin_session(native_session_id=sid,
                store=HttpStore(args.store_url), chain=chain if mode == "http_store_anvil" else None,
                provider_addr=chain.w3.eth.accounts[1], party=chain.w3.eth.accounts[2], payout_wei=1)
        setup_seconds = time.perf_counter() - setup_start
        latency = []
        cpu_start = time.process_time()
        services_start = service_cpu()
        action_start = time.perf_counter()
        try:
            for i, entry in enumerate(workload):
                result, duration = elapsed(lambda: native.dispatch("write_file", entry, task_id="practicality-native", session_id=sid, tool_call_id=f"call-{i}"))
                latency.append(duration)
                parsed = json.loads(result)
                if parsed.get("error"):
                    raise AssertionError(parsed)
            action_seconds = time.perf_counter() - action_start
            action_cpu = time.process_time() - cpu_start
            final_start = time.perf_counter()
            summary = native.plugin.end_session(native_session_id=sid) if sess else None
            final_seconds = time.perf_counter() - final_start
            total_cpu = time.process_time() - cpu_start
            services_end = service_cpu()
            if sess and sess._worker:
                sess._worker.join(timeout=5)
            effects = [hashlib.sha256(Path(entry["path"]).read_bytes()).hexdigest() for entry in workload]
            expected = hashlib.sha256(content.encode()).hexdigest()
            assert effects == [expected] * args.actions
            stored = HttpStore(args.store_url).get_records(sess.session_id) if sess else []
            if sess:
                assert len(stored) == args.actions * 4, (len(stored), args.actions)
                assert all(not verdict.violated for verdict in acc.self_check(sess.records).values())
                assert trace_hash([ActionRecord.from_dict(r) for r in stored]) == summary["trace_hash"]
                if not (args.output / "native-seed-records.json").exists():
                    dump(args.output / "native-seed-records.json", stored)
            stored_bytes = 0
            if sess:
                with sqlite3.connect(args.output / "trace-store.sqlite") as conn:
                    stored_bytes = conn.execute("SELECT COALESCE(SUM(LENGTH(CAST(payload AS BLOB))),0) FROM records WHERE session_id=?", (sess.session_id,)).fetchone()[0]
            events = chain.events[mark:]
            row = {"repetition": rep, "order_position": position, "mode": mode, "warmup": warmup,
                   "native_actions": args.actions, "capture_records": len(stored),
                   "setup_seconds": setup_seconds, "action_seconds": action_seconds,
                   "action_latencies_seconds": latency, "finalization_seconds": final_seconds,
                   "total_action_plus_finalization_seconds": action_seconds + final_seconds,
                   "client_action_cpu_seconds": action_cpu, "client_total_cpu_seconds": total_cpu,
                   "store_cpu_seconds": services_end[0] - services_start[0],
                   "anvil_cpu_seconds": services_end[1] - services_start[1],
                   "stored_payload_bytes": stored_bytes, "database_allocated_bytes": (args.output / "trace-store.sqlite").stat().st_size if (args.output / "trace-store.sqlite").exists() else 0,
                   "effects_sha256": hashlib.sha256("".join(effects).encode()).hexdigest(),
                   "effect_bytes": args.actions * len(content.encode()), "session_id": sess.session_id if sess else None,
                   "transactions": events, "summary": summary}
            with open(args.output / "runtime-raw.jsonl", "a") as out:
                out.write(json.dumps(row) + "\n")
            return row
        finally:
            native.reset_requester(token)
    try:
        for position, mode in enumerate(modes):
            one(mode, -1, position, True)
        for rep in range(args.repetitions):
            order = rng.sample(modes, len(modes))
            for position, mode in enumerate(order):
                rows.append(one(mode, rep, position))
            print(f"runtime repetition {rep+1}/{args.repetitions} complete", flush=True)
        assert len({row["effects_sha256"] for row in rows}) == 1
        summary = {}
        for mode in modes:
            subset = [r for r in rows if r["mode"] == mode]
            summary[mode] = {key: stats([r[key] for r in subset]) for key in (
                "setup_seconds", "action_seconds", "finalization_seconds", "total_action_plus_finalization_seconds",
                "client_action_cpu_seconds", "client_total_cpu_seconds", "store_cpu_seconds", "anvil_cpu_seconds", "stored_payload_bytes")}
            summary[mode]["pooled_action_latency_seconds"] = stats([t for r in subset for t in r["action_latencies_seconds"]])
            summary[mode]["checkpoint_counts"] = stats([sum(e["method"] == "checkpoint_trace" for e in r["transactions"]) for r in subset])
        baseline = {r["repetition"]: r for r in rows if r["mode"] == "capture_off"}
        summary["paired_differences_vs_capture_off"] = {mode: {
            key: paired_bootstrap([r[key] - baseline[r["repetition"]][key] for r in rows if r["mode"] == mode], args.seed)
            for key in ("action_seconds", "total_action_plus_finalization_seconds")}
            for mode in modes[1:]}
        dump(args.output / "runtime-summary.json", summary)
    finally:
        native.loop.call_soon_threadsafe(native.loop.stop)
        native.thread.join(timeout=2)
        native.loop.close()


def expanded_native_records(seed, n, sid):
    """Repeat a real native authorization/action block with fresh bound identities."""
    block = seed[:4]
    assert [r["tool"] for r in block] == ["native_authorization_request", "native_authorization_response", "user_authorization", "write_file"]
    old_action = block[0]["metadata"]["action_id"]
    old_request = block[0]["args"]["request_id"]
    old_native_request = block[0]["args"]["native_request_id"]
    old_native_session = block[0]["args"]["native_session_id"]
    old_sid = block[0]["session_id"]
    out = []
    def replace(value, mapping):
        if isinstance(value, str):
            for old, new in mapping.items():
                value = value.replace(old, new)
            return value
        if isinstance(value, list):
            return [replace(x, mapping) for x in value]
        if isinstance(value, dict):
            return {key: replace(val, mapping) for key, val in value.items()}
        return value
    for i in range(n // 4):
        mapping = {old_action: f"scale-action-{i:08d}", old_request: f"scale-request-{i:08d}",
                   old_native_request: f"scale-native-request-{i:08d}", old_native_session: "scale-native", old_sid: sid}
        for item in block:
            item = replace(item, mapping)
            item["seq"] = len(out) + 1
            item["ts"] = 1700000000000 + len(out)
            out.append(ActionRecord.from_dict(item))
    assert len(out) == n
    return out


def verify_worker(args):
    """Actual process_challenge logic; fixture roots stand in for chain reads/settlement."""
    import aa_verifier as verifier
    fixture = json.loads(args.fixture.read_text())
    phases = {"retrieval_seconds": 0., "final_hash_seconds": 0., "prefix_validation_seconds": 0., "predicate_seconds": 0.}
    class Store(HttpStore):
        def get_records(self, sid):
            result, duration = elapsed(lambda: super(Store, self).get_records(sid))
            phases["retrieval_seconds"] += duration
            return result
        def get_promise(self, pid):
            result, duration = elapsed(lambda: super(Store, self).get_promise(pid))
            phases["retrieval_seconds"] += duration
            return result
    def measured_hash(records):
        result, duration = elapsed(lambda: trace_hash(records))
        phases["final_hash_seconds"] += duration
        return result
    def measured_prefix(records, checkpoints, sid):
        result, duration = elapsed(lambda: check_prefixes(records, checkpoints, sid))
        phases["prefix_validation_seconds"] += duration
        return result
    class Registry:
        def resolve_hash(self, digest):
            spec = registry.resolve_hash(digest)
            if spec is None:
                return None
            def evaluate(records, params):
                result, duration = elapsed(lambda: spec.evaluate(records, params))
                phases["predicate_seconds"] += duration
                return result
            return SimpleNamespace(spec_id=spec.spec_id, evaluate=evaluate)
    class FixtureEscrow:
        def get_challenge(self, cid):
            return (bytes.fromhex(fixture["session_id"][2:]), fixture["promise_id"], "party", 1, 0, 1, 1)
        def get_promise(self, pid):
            return ("provider", bytes.fromhex(fixture["predicate_hash"][2:]), bytes.fromhex(fixture["params_hash"][2:]), 1, 1, 1, 0)
        def get_session(self, sid):
            return ("provider", "party", bytes.fromhex(fixture["trace_hash"][2:]), 1, 1, True)
        def get_checkpoints(self, sid):
            return fixture["checkpoints"]
        def submit_verdict(self, *unused):
            return {"paidToChallenger": 0}
    verifier.trace_hash = measured_hash
    verifier.check_prefixes = measured_prefix
    verifier.registry = Registry()
    before = rss_bytes()
    cpu_start = time.process_time()
    result, duration = elapsed(lambda: verifier.process_challenge(FixtureEscrow(), Store(args.store_url), 1, "verifier"))
    assert result["violated"] is False, result
    row = {"records": fixture["records"], "checkpoint_count": len(fixture["checkpoints"]),
           "total_seconds": duration, "cpu_seconds": time.process_time() - cpu_start,
           **phases, "peak_rss_bytes": rss_bytes(), "peak_rss_before_verification_bytes": before,
           "peak_rss_growth_bytes": max(0, rss_bytes() - before), "verdict": result,
           "roots_source": "fixture, not chain", "settlement": "stub, excluded"}
    dump(args.worker_output, row)


def scaling(args):
    seed = json.loads((args.output / "native-seed-records.json").read_text())
    store = HttpStore(args.store_url)
    spec = registry.resolve_hash(registry.predicate_hash_for("no_destructive_without_consent"))
    params = {"destructive_tools": ["write_file", "patch", "terminal", "execute_code"], "authorization_mode": "invocation"}
    rows = []
    for n in args.sizes:
        sid = "0x" + hashlib.sha256(f"scale-{n}".encode()).hexdigest()
        records = expanded_native_records(seed, n, sid)
        assert not spec.evaluate(records, params).violated
        for record in records:
            store.append_record(sid, record.to_dict())
        pid = f"scaling-{n}"
        store.put_promise(pid, {"predicate": spec.spec_id, "params": params})
        checkpoints = [{"record_count": count, "prefix_hash": trace_hash(records[:count])} for count in range(10, n + 1, 10)]
        for cadence, prefixes in (("every_10_records", checkpoints), ("final_only", [])):
            fixture = {"records": n, "session_id": sid, "promise_id": pid,
                       "trace_hash": trace_hash(records), "params_hash": params_hash(params),
                       "predicate_hash": registry.predicate_hash_for(spec.spec_id), "checkpoints": prefixes}
            path = args.output / f"scaling-fixture-{n}-{cadence}.json"
            dump(path, fixture)
            for rep in range(args.scaling_repetitions):
                output = args.output / f"scaling-{n}-{cadence}-{rep}.json"
                command = [sys.executable, str(Path(__file__).resolve()), "--mode", "verify-worker", "--fixture", str(path), "--worker-output", str(output), "--store-port", str(args.store_port)]
                subprocess.run(command, check=True)
                row = json.loads(output.read_text())
                row.update(repetition=rep, cadence=cadence, command=command)
                rows.append(row)
                with open(args.output / "scaling-raw.jsonl", "a") as out:
                    out.write(json.dumps(row) + "\n")
                print(f"verifier {n} records {cadence} rep {rep+1}: {row['total_seconds']:.3f}s", flush=True)
    dump(args.output / "scaling-summary.json", {f"{n}:{cadence}": {
        key: stats([r[key] for r in rows if r["records"] == n and r["cadence"] == cadence])
        for key in ("total_seconds", "retrieval_seconds", "final_hash_seconds", "prefix_validation_seconds", "predicate_seconds", "cpu_seconds", "peak_rss_bytes", "peak_rss_growth_bytes")}
        for n in args.sizes for cadence in ("every_10_records", "final_only")})


def cadence(args, chain):
    """Synthetic paced records on actual SDK/store/Anvil; no native timing claim."""
    runs = []
    for rep in range(args.cadence_repetitions):
        for name, count, seconds in (("10_records_30s", 10, 30), ("30_records_60s", 30, 60), ("final_only", 10**9, 10**9)):
            acc = Accountability("paced-synthetic", HttpStore(args.store_url), chain,
                chain.w3.eth.accounts[1], checkpoint_records=count, checkpoint_seconds=seconds)
            session = acc.session(chain.w3.eth.accounts[2])
            runs.append({"name": name, "rep": rep, "session": session, "record_times": [], "samples": []})
    # 20 records at 0.2s; a 65s idle interval; 20 more at 0.2s. The pause exercises timers.
    schedule = [i * .2 for i in range(20)] + [69 + i * .2 for i in range(20)]
    start = time.perf_counter()
    for i, offset in enumerate(schedule):
        remaining = start + offset - time.perf_counter()
        if remaining > 0:
            time.sleep(remaining)
        for run in runs:
            sess = run["session"]
            run["record_times"].append(time.perf_counter())
            sess.record("read_file", {"path": "workspace/fixture.txt"}, "synthetic paced fixture")
            run["samples"].append({"at": time.perf_counter(), **sess.checkpoint_status()})
    for run in runs:
        sess = run.pop("session")
        summary, final_seconds = elapsed(sess.end)
        if sess._worker:
            sess._worker.join(timeout=5)
        events = [e for e in chain.events if e.get("session_id") == sess.session_id and e["method"] in {"checkpoint_trace", "commit_trace"}]
        anchors = [(e["observed"], e.get("record_count", len(run["record_times"]))) for e in events]
        delays = [min(t for t, count in anchors if count >= i) - recorded for i, recorded in enumerate(run["record_times"], 1)]
        # Reconstruct exposure at each record and receipt event, including just-before receipts.
        timeline = sorted([(t, "record", i) for i, t in enumerate(run["record_times"], 1)] + [(t, "anchor", count) for t, count in anchors])
        recorded_count = anchored = 0
        max_count = 0
        max_age = 0.
        for at, kind, count in timeline:
            if recorded_count > anchored:
                max_age = max(max_age, at - run["record_times"][anchored])
            if kind == "record":
                recorded_count = count
            else:
                anchored = max(anchored, count)
            max_count = max(max_count, recorded_count - anchored)
        run.update(session_id=sess.session_id, finalization_seconds=final_seconds, summary=summary,
                   transactions=events, record_to_observed_anchor_seconds=delays,
                   max_unanchored_records=max_count, max_unanchored_age_seconds=max_age)
    dump(args.output / "cadence-raw.json", {"kind": "synthetic paced SDK records, actual local Anvil receipts",
        "schedule_seconds": schedule, "concurrent_sessions": len(runs), "runs": runs})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--mode", choices=["all", "runtime", "scaling", "cadence", "verify-worker"], default="all")
    parser.add_argument("--output", type=Path, default=Path("/Users/chenghua/research/.local/base-mainnet-eval-20260916/results/local-performance"))
    parser.add_argument("--hermes", type=Path, default=Path("/Users/chenghua/research/hermes-agent"))
    parser.add_argument("--store-port", type=int, default=18548)
    parser.add_argument("--anvil-port", type=int, default=18547)
    parser.add_argument("--seed", type=int, default=20260916)
    parser.add_argument("--actions", type=int, default=100)
    parser.add_argument("--repetitions", type=int, default=30)
    parser.add_argument("--sizes", type=int, nargs="+", default=[100, 1000, 10000])
    parser.add_argument("--scaling-repetitions", type=int, default=5)
    parser.add_argument("--cadence-repetitions", type=int, default=3)
    parser.add_argument("--fixture", type=Path)
    parser.add_argument("--worker-output", type=Path)
    args = parser.parse_args()
    args.store_url = f"http://127.0.0.1:{args.store_port}"
    args.rpc_url = f"http://127.0.0.1:{args.anvil_port}"
    if args.mode == "verify-worker":
        verify_worker(args)
        return
    args.output.mkdir(parents=True, exist_ok=True)
    metadata = {"command": [sys.executable, *sys.argv], "started_unix": time.time(),
        "platform": platform.platform(), "machine": platform.machine(), "python": sys.version,
        "repo": str(REPO), "revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, text=True).strip(),
        "hermes_revision": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=args.hermes, text=True).strip(),
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "versions": {p: importlib.metadata.version(p) for p in ("web3", "requests", "uvicorn", "fastapi", "psutil", "agent-client-protocol")},
        "anvil_version": subprocess.check_output([str(Path.home()/".foundry/bin/anvil"), "--version"], text=True).strip(),
        "config": vars(args), "module_origins": C.verify_package_origins()}
    if metadata["hermes_revision"] != "9801de7052b9f746791f96600ea19b9399de4b13":
        raise RuntimeError("Hermes checkout is not the pinned fork")
    dump(args.output / "metadata.json", metadata)
    with Services(args) as services:
        w3 = Web3(Web3.HTTPProvider(args.rpc_url))
        if w3.eth.chain_id != 31337:
            raise RuntimeError("Local chain guard failed")
        chain = TimedChain(EscrowClient.deploy(w3, C.ARTIFACT, w3.eth.accounts[0], w3.eth.accounts[3]))
        if args.mode in {"all", "runtime"}:
            runtime(args, chain, services)
        if args.mode in {"all", "scaling"}:
            scaling(args)
        if args.mode in {"all", "cadence"}:
            cadence(args, chain)
        dump(args.output / "chain-events.json", chain.events)
    metadata["completed_unix"] = time.time()
    metadata["module_origins"] = C.verify_package_origins()
    dump(args.output / "metadata.json", metadata)


if __name__ == "__main__":
    main()
